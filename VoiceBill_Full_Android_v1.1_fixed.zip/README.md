# Voice Bill — Full Android starter v1.0
A self-contained Android Studio project using SQLite and Android SpeechRecognizer.

Included:
- Hindi/Hinglish voice billing
- Local product database
- Price, GST and stock
- Cart and totals
- GST calculation in invoice preview
- Cash/UPI/Credit payment UI
- Bill history storage
- Share bill using Android share sheet
- Offline-first database

Important:
This is a complete runnable starter project, not a certified GST/accounting product. Before commercial deployment, validate GST invoice rules, printer models, tax rounding, backup/security, and test voice recognition across devices.
Open the folder in Android Studio and Run.
