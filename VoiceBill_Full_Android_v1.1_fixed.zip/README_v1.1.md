# VoiceBill v1.1

इस version में core billing flow को बेहतर किया गया है:
- Hindi/Hinglish voice billing
- कई common product aliases
- Hindi quantity words की basic पहचान
- Cart में item/quantity
- Bill final होने पर stock घटाने का flow
- Cash / UPI / Credit payment selection
- Product और stock screen
- Bill share करना

यह अभी development/starter build है; commercial GST/accounting use से पहले testing और आगे के modules (persistent database, customer ledger, invoice numbering, printer, backup/restore आदि) जरूरी हैं।
