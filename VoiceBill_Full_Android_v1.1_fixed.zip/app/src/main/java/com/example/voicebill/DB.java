package com.example.voicebill;
import android.content.*; import android.database.sqlite.*; import android.database.Cursor; import java.util.*;
public class DB extends SQLiteOpenHelper {
 public DB(Context c){super(c,"voicebill.db",null,1);}
 public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE,price REAL,stock REAL,gst REAL)");d.execSQL("CREATE TABLE bills(id INTEGER PRIMARY KEY AUTOINCREMENT,created INTEGER,total REAL,payment TEXT)");}
 public void onUpgrade(SQLiteDatabase d,int o,int n){}
 public void seed(){SQLiteDatabase d=getWritableDatabase();String[][] a={{"Amul Milk","65","100","5"},{"Parle-G","10","100","5"},{"Pepsi","40","100","18"},{"Tata Salt","30","100","5"},{"Bread","40","100","5"}};for(String[]x:a){ContentValues v=new ContentValues();v.put("name",x[0]);v.put("price",Double.parseDouble(x[1]));v.put("stock",Double.parseDouble(x[2]));v.put("gst",Double.parseDouble(x[3]));d.insertWithOnConflict("products",null,v,SQLiteDatabase.CONFLICT_IGNORE);}}
 public Cursor all(){return getReadableDatabase().rawQuery("SELECT id,name,price,stock,gst FROM products ORDER BY name",null);}
 public Cursor find(String q){return getReadableDatabase().rawQuery("SELECT id,name,price,stock,gst FROM products WHERE lower(name)=lower(?) OR lower(name) LIKE lower(?) ORDER BY name LIMIT 1",new String[]{q,"%"+q+"%"});}
 public long addProduct(String n,double p,double s,double g){ContentValues v=new ContentValues();v.put("name",n);v.put("price",p);v.put("stock",s);v.put("gst",g);return getWritableDatabase().insertWithOnConflict("products",null,v,SQLiteDatabase.CONFLICT_REPLACE);}
 public void stock(String n,double delta){getWritableDatabase().execSQL("UPDATE products SET stock=stock+? WHERE name=?",new Object[]{delta,n});}
 public long bill(double total,String payment){ContentValues v=new ContentValues();v.put("created",System.currentTimeMillis());v.put("total",total);v.put("payment",payment);return getWritableDatabase().insert("bills",null,v);}
}